import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getShopItems } from '../../../api/inventory';

export default function FoodShop() {
  const navigate = useNavigate();
  const [items, setItems] = useState([]);

  const [cart, setCart] = useState([]);

  const addToCart = (item) => {
    setCart(prev => {
      const existing = prev.find(i => i.item_id === item.item_id);
      if (existing) return prev.map(i => i.item_id === item.item_id ? { ...i, quantity: i.quantity + 1 } : i);
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const cartTotal = cart.reduce((sum, i) => sum + i.price_cents * i.quantity, 0);

  const handleCheckout = () => {
    if (cart.length === 0) return alert('Add items to your cart first.');
    navigate('/checkout', { state: { cartItems: cart, cartTotal } });
  };

  useEffect(() => {
    getShopItems(2).then(setItems);
  }, []);

  return (
    <div style={{ color: 'white', padding: '20px', boxSizing: 'border-box' }}>
      <section style={{ marginBottom: '40px' }}>
        <h1 style={{ fontSize: '42px', marginBottom: '12px', textAlign: 'center' }}>
          Food Shop
        </h1>
        <p style={{ color: 'var(--color-text-muted)', textAlign: 'center' }}>
          Preview and Place your order for for any of the snacks/meals across the park! 
        </p>
      </section>

      <section
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: '12px',
          width: '100%',
          boxSizing: 'border-box',
        }}
      >
        {items.map((item) => (
          <div
            key={item.item_id}
            className="glass-panel"
            style={{ padding: '16px', borderRadius: '32px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}
          >
            {item.image_url && (
              <div style={{ width: '100%', borderRadius: '20px', overflow: 'hidden', marginBottom: '12px' }}>
                <img
                  src={item.image_url}
                  alt={item.item_name}
                  style={{ width: '100%', height: '200px', objectFit: 'cover', display: 'block' }}
                />
              </div>
            )}
            <h2 style={{ marginTop: 0 }}>{item.item_name}</h2>
            <p style={{ color: 'var(--color-text-muted)' }}>{item.description}</p>
            <p style={{ color: 'var(--color-primary)', fontWeight: 700 }}>
              ${(item.price_cents / 100).toFixed(2)}
            </p>
            <button className="glass-button" style={{ marginTop: 'auto', paddingTop: '16px' }} onClick={() => addToCart(item)}>
              Add to Cart
            </button>
          </div>
        ))}
      </section>
        {cart.length > 0 && (
          <div style={{ position: 'fixed', bottom: '20px', right: '20px', background: 'var(--glass-bg)', border: '1px solid var(--glass-border)', padding: '16px 24px', borderRadius: '16px', display: 'flex', alignItems: 'center', gap: '20px' }}>
            <span>{cart.reduce((s, i) => s + i.quantity, 0)} items — ${(cartTotal / 100).toFixed(2)}</span>
            <button className="glass-button" onClick={handleCheckout}>Proceed to Checkout</button>
          </div>
        )}
      <button
        className="glass-button"
        onClick={() => navigate('/shop')}
        style={{ position: 'absolute', top: '20px', left: '20px' }}
      >
        Back
      </button>
    </div>
  );
}